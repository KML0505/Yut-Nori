# Yut Nori
Run: `npx serve .` (or any static server), open http://localhost:3000.
## Firebase setup
1. Create a Firebase project, add a Web app, paste its config into `js/firebase-config.js`.
2. Authentication > Sign-in method > enable Google. Add your domain (and localhost) to Authorized domains.
3. Create a Firestore database and publish `firestore.rules`.
Without a config the app runs in local-only mode (nickname login in localStorage).
## Notes
- Records live on the user doc and are written by the client; use a Cloud Function for tamper-proof leaderboards.
- Party lobbies sync live; gameplay itself is still hot-seat on the host’s screen (sync `G` through the party doc next).
