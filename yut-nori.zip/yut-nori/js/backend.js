// Firebase layer. If the config is not filled in, Backend.on stays false and the app falls back to local storage.
const Backend={on:false,user:null,onUser:null,
init(){if(!window.firebase||!FIREBASE_CONFIG.apiKey||FIREBASE_CONFIG.apiKey.startsWith('YOUR'))return;
 firebase.initializeApp(FIREBASE_CONFIG);this.auth=firebase.auth();this.db=firebase.firestore();this.on=true;
 this.auth.onAuthStateChanged(u=>this.onUser&&this.onUser(u))},
async google(){await this.auth.signInWithPopup(new firebase.auth.GoogleAuthProvider())},
async getProfile(uid){const s=await this.db.doc('users/'+uid).get();return s.exists?s.data():null},
saveProfile(uid,p){return this.db.doc('users/'+uid).set(p,{merge:true}).catch(e=>console.error(e))},
// Unique nickname: one Google account = one profile, and nicknames/{lowercase} can only be claimed once.
claim(uid,name,p){const nk=this.db.doc('nicknames/'+name.toLowerCase()),uk=this.db.doc('users/'+uid);
 return this.db.runTransaction(async t=>{if((await t.get(nk)).exists)throw new Error('Nickname is taken');if((await t.get(uk)).exists)throw new Error('This account already has a nickname');p.uid=uid;t.set(nk,{uid});t.set(uk,p);return p})},
pub(u){return{uid:u.uid,name:u.name,av:u.av,pc:u.pc}},
createParty(code,u){return this.db.doc('parties/'+code).set({host:u.uid,players:[this.pub(u)],status:'lobby'})},
joinParty(code,u){const r=this.db.doc('parties/'+code);return this.db.runTransaction(async t=>{const s=await t.get(r);if(!s.exists)throw new Error('Party not found');const d=s.data();if(d.players.some(p=>p.uid==u.uid))return;if(d.players.length>=4)throw new Error('Party is full');t.update(r,{players:[...d.players,this.pub(u)]})})},
watch(code,cb){return this.db.doc('parties/'+code).onSnapshot(s=>s.exists&&cb(s.data()))}};
