const $=s=>document.querySelector(s),sleep=t=>new Promise(r=>setTimeout(r,t));
const AV={horse:'🐴',sheep:'🐑',cow:'🐮',dog:'🐶',pig:'🐷'},COL=['#e8a46a','#6ab0e8','#7bd389','#d98bd9','#e86a6a','#f2d45c'];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
let DB={users:{},cur:null},me=null,G=null;
try{const d=JSON.parse(localStorage.getItem('yut'));if(d&&d.users)DB=d}catch(e){}
function save(){try{localStorage.setItem('yut',JSON.stringify(DB))}catch(e){}if(Backend.on&&me&&me.uid)Backend.saveProfile(me.uid,me)}
function toast(t){const e=$('#toast');e.textContent=t;e.style.display='block';setTimeout(()=>e.style.display='none',2800)}
me=DB.cur&&DB.users[DB.cur]||null;
$('#ttl').innerHTML=[...'Yut Nori'].map((c,i)=>`<span style="animation-delay:${i*.09}s">${c==' '?'&nbsp;':c}</span>`).join('');
function show(v){document.querySelectorAll('.v').forEach(e=>e.classList.toggle('on',e.id==v));if(v=='profile'){if(!me)return show('auth');renderProfile()}$('#navp').textContent=me?me.name:'Sign in';scrollTo(0,0)}
function face(f,color,big){const inner=f&&f.type=='img'?`<img src="${f.v}" alt="">`:f&&f.type=='char'?AV[f.v]:'';return `<span class="tok ${big?'l':''}" style="background:${color||'#444'}">${inner}</span>`}
async function google(){if(!Backend.on)return toast('Add your Firebase config in js/firebase-config.js');try{await Backend.google()}catch(e){toast(e.message)}}
function newUser(n){return{name:n,av:{type:'char',v:'horse'},pc:{color:COL[0],type:'char',v:'horse'},rec:{played:0,wins:0}}}
async function login(){const n=$('#nick').value.trim();if(!/^[\w\-가-힣]{2,16}$/.test(n))return toast('Use 2–16 letters, numbers, - or _');
 if(Backend.on){if(!Backend.user)return toast('Continue with Google first');try{me=await Backend.claim(Backend.user.uid,n,newUser(n))}catch(e){return toast(e.message)}return done()}
 const k=n.toLowerCase();if(!DB.users[k])DB.users[k]=newUser(n);DB.cur=k;me=DB.users[k];save();done()}
function done(){const w=want;want=null;show('home');toast('Welcome, '+me.name+'!');if(w)start(w)}
function logout(){if(Backend.on)Backend.auth.signOut();DB.cur=null;me=null;try{localStorage.setItem('yut',JSON.stringify(DB))}catch(e){}show('home')}
let want=null;
function play(n){if(!me){want=n;return show('auth')}start(n)}
let PARTY=null,unsub=null;
function party(){if(!me)return show('auth');if(!Backend.on)return toast('Party mode needs Firebase configured');
 $('#mbox').innerHTML=`<h2>Party mode</h2><button onclick="mkParty()">Create party</button><input id="pc" maxlength="5" placeholder="Party code" style="text-transform:uppercase"><button class="g" onclick="joinParty()">Join</button><button class="g" onclick="closeM()">Close</button>`;$('#modal').classList.add('on')}
async function mkParty(){const c=Math.random().toString(36).slice(2,7).toUpperCase();await Backend.createParty(c,me);watchParty(c)}
async function joinParty(){const c=$('#pc').value.trim().toUpperCase();try{await Backend.joinParty(c,me)}catch(e){return toast(e.message)}watchParty(c)}
function watchParty(c){if(unsub)unsub();unsub=Backend.watch(c,d=>{PARTY=d;const host=d.host==me.uid;
 $('#mbox').innerHTML=`<h2>Party ${c}</h2>${d.players.map(p=>`<div class="pl">${face(p.av,p.pc.color,1)}<b>${esc(p.name)}</b></div>`).join('')}${host?`<button ${d.players.length<2?'disabled':''} onclick="closeM();start(PARTY.players.length,PARTY.players)">Start (${d.players.length} players)</button>`:'<p style="color:var(--mut)">Waiting for the host…</p>'}<button class="g" onclick="closeM()">Close</button>`;$('#modal').classList.add('on')})}
function closeM(){$('#modal').classList.remove('on')}
// profile
function renderProfile(){$('#pname').textContent=me.name;
 const ch=(cur,fn,none)=>Object.keys(AV).map(k=>`<div class="pick ${cur.type=='char'&&cur.v==k?'s':''}" onclick="${fn}({type:'char',v:'${k}'})">${face({type:'char',v:k},'#555')}</div>`).join('')+(none?`<div class="pick ${cur.type=='none'?'s':''}" onclick="${fn}({type:'none'})">${face(null,me.pc.color)}</div>`:'')+`<label class="pick" style="cursor:pointer">Upload<input type="file" accept="image/*" hidden onchange="up(this,'${fn}')"></label>`;
 $('#avopts').innerHTML=face(me.av,'#555',1)+ch(me.av,'setAv');$('#pcopts').innerHTML=ch(me.pc,'setPcF',1);$('#pcol').value=me.pc.color;$('#pprev').innerHTML=face(me.pc,me.pc.color,1);
 const r=me.rec;$('#rec').innerHTML=`<td>${r.played}</td><td>${r.wins}</td><td>${r.played-r.wins}</td>`}
function setAv(a){me.av=a;save();renderProfile()}function setPcF(a){me.pc=Object.assign(me.pc,a);if(a.type=='none')me.pc.v=null;save();renderProfile()}function setPc(o){Object.assign(me.pc,o);save();$('#pprev').innerHTML=face(me.pc,me.pc.color,1)}
function up(el,fn){const f=el.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const c=document.createElement('canvas');c.width=c.height=96;const x=c.getContext('2d'),s=Math.min(im.width,im.height);x.drawImage(im,(im.width-s)/2,(im.height-s)/2,s,s,0,0,96,96);window[fn]({type:'img',v:c.toDataURL('image/jpeg',.8)})};im.src=r.result};r.readAsDataURL(f)}
// board
const M=[...Array(19)].map((_,i)=>i+1).concat('F'),A=[20,21,22,23,24,15,16,17,18,19,'F'],B=[25,26,22,27,28,'F'];
function xy(n){if(n<20){const s=n>>2>=5?0:Math.floor(n/5),t=n%5,d=88;return [[480,480-d*t],[480-d*t,40],[40,40+d*t],[40+d*t,480]][s]}
 const l=(a,b,f)=>[a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f],C=[260,260];
 if(n==22)return C;if(n<=24)return n<22?l([480,40],C,(n-19)/3):l(C,[40,480],(n-22)/3);return n<=26?l([40,40],C,(n-24)/3):l(C,[480,480],(n-22-2)/3)}
function nodeList(){return [...Array(29).keys()]}
function start(n,roster){const mc=me.pc.color,oc=COL.filter(c=>c!=mc),ch=['cow','dog','pig','sheep'];
 const mk=(name,ai,color,f,a)=>({name,ai,color,f,av:a,pcs:[0,1,2,3].map(()=>({node:null,route:M,idx:-1,done:false}))});
 const pl=[mk(me.name,false,mc,me.pc,me.av)];
 for(let i=1;i<(n==1?2:n);i++){const c=n==1?'sheep':ch[i-1],r=roster&&roster[i],f=r?r.pc:{type:'char',v:c};pl.push(mk(r?r.name:n==1?'AI':'Guest '+(i+1),n==1,r?r.pc.color:oc[i-1],f,r?r.av:f))}
 G={n,pl,turn:0,roll:null,busy:false,over:false};show('game');$('#res').textContent='';sticks([1,1,1,1]);render()}
const cur=()=>G.pl[G.turn],NAMES={1:'Do',2:'Ge',3:'Geol',4:'Yut',5:'Mo'};
function sticks(f){$('#sticks').innerHTML=f.map(x=>`<div class="stick ${x?'f':'r'}"></div>`).join('')}
async function doRoll(){if(G.busy||G.roll!=null||G.over)return;G.busy=true;render();
 const f=[0,1,2,3].map(()=>Math.random()<.6?1:0);$('#res').textContent='';
 document.querySelectorAll('.stick').forEach((e,i)=>{e.style.animationDelay=i*60+'ms';e.classList.add('toss')});await sleep(1000);
 sticks(f);const c=f.reduce((a,b)=>a+b,0),v=c==0?5:c;G.roll=v;G.busy=false;
 $('#res').textContent=NAMES[v]+' · '+v+(v>=4?' · throw again after!':'');render();
 if(cur().ai){await sleep(800);move(aiPick())}}
function sim(q,s){const c=Object.assign({},q);adv(c,s);return c}
function adv(q,s){if(q.node===5&&q.route===M){q.route=A;q.idx=-1}else if(q.node===10&&q.route===M){q.route=B;q.idx=-1}
 q.idx+=s;if(q.idx>=q.route.length-1){q.done=true;q.node=null}else q.node=q.route[q.idx]}
function aiPick(){let best=-1,bs=-1e9;cur().pcs.forEach((q,i)=>{if(q.done)return;const d=sim(q,G.roll);let s=Math.random()*3+(d.done?60:d.idx);
 if(d.node!==null&&G.pl.some((p,pi)=>pi!=G.turn&&p.pcs.some(o=>o.node===d.node)))s+=100;if(q.node!==null)s+=2;if(s>bs){bs=s;best=i}});return best}
function pick(i){if(G.roll==null||G.busy||cur().ai||G.over)return;move(i)}
function move(i){const p=cur(),pc=p.pcs[i];if(!pc||pc.done)return;
 const grp=pc.node===null?[pc]:p.pcs.filter(q=>!q.done&&q.node===pc.node);grp.forEach(q=>adv(q,G.roll));
 let cap=false;const d=pc.node;if(d!==null)G.pl.forEach((o,k)=>{if(k!=G.turn)o.pcs.forEach(q=>{if(q.node===d){q.node=null;q.route=M;q.idx=-1;cap=true}})});
 const extra=G.roll>=4||cap;G.roll=null;
 if(p.pcs.every(q=>q.done)){G.over=true;render();return end(p)}
 if(!extra)G.turn=(G.turn+1)%G.pl.length;$('#hint').textContent=cap?'Captured! Throw again.':'';render();
 if(cur().ai)setTimeout(doRoll,900)}
function end(w){let t='';if(G.n>=2){me.rec.played++;if(w===G.pl[0])me.rec.wins++;save();t='Result saved to your record.'}else t='Practice game: not counted.';
 $('#mbox').innerHTML=`<h2>${esc(w.name)} wins!</h2><p style="color:var(--mut)">${t}</p><div class="row"><button onclick="closeM();start(${G.n})">Play again</button><button class="g" onclick="closeM();show('home')">Home</button></div>`;$('#modal').classList.add('on')}
function render(){const c=cur(),can=G.roll!=null&&!c.ai&&!G.over;
 $('#rollb').disabled=G.busy||G.roll!=null||c.ai||G.over;if(G.roll!=null&&!c.ai)$('#hint').textContent='Click a glowing piece (or one at home) to move.';
 $('#side').innerHTML=G.pl.map((p,k)=>`<div class="pl ${k==G.turn?'t':''}">${face(p.av,p.color,1)}<div><b>${esc(p.name)}</b>${p.ai?' (AI)':''}<small>Online · ${p.pcs.filter(q=>q.done).length}/4 home</small><div class="tray">${p.pcs.map((q,i)=>q.node===null&&!q.done?`<span onclick="${k==G.turn?`pick(${i})`:''}">${face(p.f,p.color)}</span>`:'').join('')}</div></div></div>`).join('');
 let s='<defs><clipPath id="cp" clipPathUnits="objectBoundingBox"><circle cx=".5" cy=".5" r=".5"/></clipPath></defs>';
 s+='<g stroke="#6b5640" stroke-width="3" fill="none"><rect x="40" y="40" width="440" height="440" rx="4"/><path d="M480 40L40 480M40 40L480 480"/></g>';
 nodeList().forEach(n=>{const [x,y]=xy(n),big=[0,5,10,15,22].includes(n);s+=`<circle cx="${x}" cy="${y}" r="${big?24:14}" fill="${big?'#3a2d20':'#4a3a2a'}" stroke="#8a6d4d" stroke-width="2"/>`});
 const [sx,sy]=xy(0);s+=`<text x="${sx}" y="${sy+5}" text-anchor="middle" font-size="12" fill="#f2b27a">START</text>`;
 const at={};G.pl.forEach((p,k)=>p.pcs.forEach((q,i)=>{if(q.node===null)return;const o=at[q.node]=(at[q.node]||0)+1-1,m=at[q.node];at[q.node]=m+1;const [x,y]=xy(q.node),sel=can&&k==G.turn,dx=m*7-4,dy=-m*7;
  const inner=p.f.type=='img'?`<image href="${p.f.v}" x="${x+dx-14}" y="${y+dy-14}" width="28" height="28" clip-path="url(#cp)"/>`:p.f.type=='char'?`<text x="${x+dx}" y="${y+dy+7}" text-anchor="middle" font-size="20">${AV[p.f.v]}</text>`:'';
  s+=`<g class="pc ${sel?'sel':''}" ${sel?`onclick="pick(${i})"`:''}><circle cx="${x+dx}" cy="${y+dy}" r="18" fill="${p.color}" stroke="#fff" stroke-width="2.5"/>${inner}${sel?`<circle class="ring" cx="${x+dx}" cy="${y+dy}" r="22" fill="none" stroke="#fff" stroke-width="3"/>`:''}</g>`}));
 $('#board').innerHTML=s}
addEventListener('keydown',e=>{if(e.key==' '&&$('#game').classList.contains('on')){e.preventDefault();doRoll()}});
Backend.onUser=async u=>{Backend.user=u;if(!u)return;const p=await Backend.getProfile(u.uid);if(p){me=p;done()}else{show('auth');toast('Choose a unique nickname')}};
Backend.init();
show('home');